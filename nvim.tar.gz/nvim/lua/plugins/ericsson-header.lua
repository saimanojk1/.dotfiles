-- Define a function that adds a specific header based on the filetype
local function add_header()
  -- Get the current filetype
  local filetype = vim.bo.filetype

  -- Define the headers for different languages
  local headers = {
    python = [[
# Copyright (c) 2009-%s Ericsson Mobile Financial Services AB, sweden. All rights reserved.
#
# The Copyright to the computer program(s) herein is the property of Ericsson mobile financial
# services ab, sweden. the program(s) may be used and/or copied with the written permission from
# ericsson mobile financial services ab or in accordance with the terms and conditions stipulated
# in the agreement/contract under which the program(s) have been supplied.
]],
    default = [[
/*
Copyright (c) 2009-%s Ericsson Mobile Financial Services AB, Sweden. All rights reserved.

The Copyright to the computer program(s) herein is the property of Ericsson Mobile Financial
Services AB, Sweden. The program(s) may be used and/or copied with the written permission from
Ericsson Mobile Financial Services AB or in accordance with the terms and conditions stipulated
in the agreement/contract under which the program(s) have been supplied.
*/
]],
  }

  -- Get the current date in the format YYYY-MM-DD
  local date = os.date("%Y")

  -- Choose the appropriate header based on the filetype or use the default
  local header = headers[filetype] or headers.default

  -- Format the header with the current date
  header = string.format(header, date)

  -- Get the current buffer
  local bufnr = vim.api.nvim_get_current_buf()

  -- Insert the header at the top of the file
  vim.api.nvim_buf_set_lines(bufnr, 0, 0, false, vim.split(header, '\n'))

  -- Optionally move the cursor down after the header
  vim.api.nvim_win_set_cursor(0, { 10, 0 })
end

-- Create a Neovim command to invoke the add_header function
vim.api.nvim_create_user_command('EricssonHeader', add_header, {})

vim.keymap.set("n", "<leader>eh", ":EricssonHeader<CR>:w<CR>", {})
return {}

